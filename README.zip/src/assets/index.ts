export {default as WeatherImage} from "./WeatherImage.png"
export { default as Like } from "./like.png";
export { default as Dislike } from "./dislike.png";