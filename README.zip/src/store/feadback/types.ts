export interface FeadbackState {
    likes: number;
    dislikes: number;
}