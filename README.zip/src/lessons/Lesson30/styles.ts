import { WeatherImage } from "assets";
import styled from "styled-components";

export const Lesson30Wrapper = styled.div`
  display: flex;
  flex: 1;
  padding: 40px;
  justify-content: center;
  background: url(${WeatherImage});`