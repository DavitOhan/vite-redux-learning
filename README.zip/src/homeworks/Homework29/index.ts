import Homework29 from "./Homework29"

export default Homework29
